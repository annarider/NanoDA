runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/text_learning/vectorize_text.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/text_learning')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection/find_signature.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/text_learning/vectorize_text.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/text_learning')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection/find_signature.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection')
words_file = "../text_learning/your_word_data.pkl" 
authors_file = "../text_learning/your_email_authors.pkl"
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection/find_signature.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection')
version()
version
import sys
print sys.version
import sys
print sys.version
exit()
exit
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection/find_signature.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/feature_selection')

##---(Sun Jul 19 23:38:17 2015)---
import sys
print sys.version
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/pca/eigenfaces.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/pca')
dir(pac)
dir(pca)
pca.explained_variance_
print pca.explained_variance_ratio_[0]
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/pca/eigenfaces.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/pca')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/validation/validate_poi.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/validation')

##---(Sun Jul 26 20:52:53 2015)---
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation/evaluate_poi_identifier.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation')
pre = [1,2,1,3,2,1,2,43,1,1]
pre == 1
len(pre)
len(pre == 1)
p = [i + 1 for e in pre if e == 1]
i = 0
p = [i + 1 for e in pre if e == 1]
p
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation/evaluate_poi_identifier.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation')
lambda x: x + 1 for e in pred if e == 1
lambda x: [x + 1 for e in pred if e == 1]
print lambda x: [x + 1 for e in pred if e == 1] 
print x
print 1+ lambda x: [x + 1 for e in pred if e == 1] 
t= lambda x: [x + 1 for e in pred if e == 1] 
print t
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation/evaluate_poi_identifier.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation')
print zip(labels_test, prediction)
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation/evaluate_poi_identifier.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/evaluation')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/datasets_questions/explore_num_people.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/datasets_questions')

##---(Tue Jul 28 17:38:49 2015)---
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers/enron_outliers.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/datasets_questions/explore_num_people.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/datasets_questions')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/datasets_questions/explore_enron_data.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/datasets_questions')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
type(test_idx)
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/tools/feature_format.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/tools')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')

##---(Wed Jul 29 23:02:37 2015)---
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/tools/feature_format.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/tools')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')

##---(Sat Aug  1 14:16:19 2015)---
l=range(15)
l
l[::2]
l[::-1]
l[::3]
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers/enron_outliers.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers/enron_outliers_salary_payments.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/k_means/k_means_cluster.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/k_means')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers/enron_outliers_salary_payments.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers')
type(poi_feature)
print poi_feature
print data
data_dict.keys()
data_dict[0].keys()
data_dict[data_dict.keys()[0]].keys()
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers/enron_outliers_salary_payments.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/outliers')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')

##---(Sat Aug  1 23:12:44 2015)---
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/anna_tester.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/enron_outliers_salary_payments.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/poi_id.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')
s=[1]
print s
print s.tostring()
s = [1,2,3]
prin ts
print s
print [1]
print s[1]
runfile('/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project/enron_outliers_salary_payments.py', wdir=r'/Users/horsepower/Dropbox/Udacity/NanoDA/IntroMachineLearning/final_project')