# -*- coding: utf-8 -*-
"""
Spyder Editor

Lesson 4: Problem Set

Question 4: Better Splitting
"""

#def split_string(source,splitlist):
 
print(hello world)   

