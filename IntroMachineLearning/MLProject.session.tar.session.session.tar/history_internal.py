# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Wed Jun 17 23:06:57 2015)---
hello
print 'hello'
python